package com.xiyuan;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * Unit test for simple RpcServerApp.
 */
public class RpcServerAppTest
{
    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue()
    {
        assertTrue( true );
    }
}
